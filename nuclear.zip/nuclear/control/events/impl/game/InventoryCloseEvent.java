package nuclear.control.events.impl.game;

import lombok.AllArgsConstructor;
import nuclear.control.events.Event;

@AllArgsConstructor
public class InventoryCloseEvent extends Event {

    public int windowId;

}


