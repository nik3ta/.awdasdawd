package nuclear.control.events.impl.game;

import nuclear.control.events.Event;

public class EventDestroyBlock extends Event  {
}
