package nuclear.control.events.impl.player;

import nuclear.control.events.Event;

public class StartFallFlyingEvent extends Event {
}
