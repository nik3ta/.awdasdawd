package nuclear.control.events.impl.player;

import nuclear.control.events.Event;

public class EventNoSlow extends Event {
}
