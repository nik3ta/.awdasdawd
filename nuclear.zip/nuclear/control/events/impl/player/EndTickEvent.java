package nuclear.control.events.impl.player;

import nuclear.control.events.Event;

public class EndTickEvent extends Event {
}

