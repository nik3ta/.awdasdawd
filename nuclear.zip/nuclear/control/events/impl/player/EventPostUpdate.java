package nuclear.control.events.impl.player;

import lombok.Data;
import nuclear.control.events.Event;

@Data
public class EventPostUpdate extends Event {
}
