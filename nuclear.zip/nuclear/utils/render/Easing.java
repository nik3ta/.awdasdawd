package nuclear.utils.render;

@FunctionalInterface
public interface Easing {
    double ease(double value);
}
