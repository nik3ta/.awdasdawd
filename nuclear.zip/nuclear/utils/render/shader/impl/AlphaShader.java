package nuclear.utils.render.shader.impl;

import nuclear.utils.render.shader.core.Shader;

public class AlphaShader extends Shader {


    public AlphaShader(String path) {
        super(path);
    }




}
